% test MSS-Estimators
clear; clc;
clean=audioread('clean.wav');
noise_model=audioread('noise_model.wav');
noisy=audioread('noisy.wav');
map=audioread('out_map.wav');
spzc=audioread('out_mmse_spzc.wav');




subplot(5,1,1);
plot(clean);
xlabel('Time in seconds');
ylabel('Amplitude');
title('Clean speech signal');

subplot(5,1,2);
plot(noise_model);
xlabel('Time in seconds');
ylabel('Amplitude');
title('Noise model');

subplot(5,1,3);
plot(noisy);
xlabel('Time in seconds');
ylabel('Amplitude');
title('Noisy speech signal');

subplot(5,1,4);
plot(map);
xlabel('Time in seconds');
ylabel('Amplitude');
title('Enhanced speech signal from MAP method');

subplot(5,1,5);
plot(spzc);
xlabel('Time in seconds');
ylabel('Amplitude');
title('Enhanced speech signal from MMSE-SPZC method');


